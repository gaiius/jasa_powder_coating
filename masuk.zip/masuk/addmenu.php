<form action="simpan_menu.php" method="post">
<table width="393" height="359" border="0" align="center">
  <tr>
    <td colspan="3">
    	<center>
        		<h3>
        	Add Menu
            	</h3>
        		<p>&nbsp;</p>
        </center>
    </td>
  </tr>
  <tr>
    <td width="159">Name</td>
    <td width="33">:</td>
    <td width="179">
    	<input type="text" name="name" />
        <h5><div id="disp"></div></h5>
    </td>
  </tr>
  <tr>
    <td>Link</td>
    <td>:</td>
    <td>
    	<input type="text" name="link"/>
    </td>
  </tr>
</table>
</form>